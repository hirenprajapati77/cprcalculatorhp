-- CreateTable
CREATE TABLE "Calculation" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "high" REAL NOT NULL,
    "low" REAL NOT NULL,
    "close" REAL NOT NULL,
    "pivot" REAL NOT NULL,
    "bc" REAL NOT NULL,
    "tc" REAL NOT NULL,
    "r1" REAL NOT NULL,
    "r2" REAL NOT NULL,
    "r3" REAL NOT NULL,
    "r4" REAL NOT NULL,
    "s1" REAL NOT NULL,
    "s2" REAL NOT NULL,
    "s3" REAL NOT NULL,
    "s4" REAL NOT NULL,
    "width" REAL NOT NULL,
    "classification" TEXT NOT NULL,
    "trend" TEXT NOT NULL,
    "shareToken" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "ScannerResult" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "symbol" TEXT NOT NULL,
    "date" TEXT NOT NULL,
    "ltp" REAL NOT NULL,
    "volume" REAL NOT NULL,
    "pivot" REAL NOT NULL,
    "bc" REAL NOT NULL,
    "tc" REAL NOT NULL,
    "r1" REAL NOT NULL,
    "r2" REAL NOT NULL,
    "r3" REAL NOT NULL,
    "r4" REAL NOT NULL,
    "s1" REAL NOT NULL,
    "s2" REAL NOT NULL,
    "s3" REAL NOT NULL,
    "s4" REAL NOT NULL,
    "width" REAL NOT NULL,
    "classification" TEXT NOT NULL,
    "score" INTEGER NOT NULL,
    "confidence" INTEGER NOT NULL DEFAULT 50,
    "signalSummary" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "MarketSnapshot" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "symbol" TEXT NOT NULL,
    "price" REAL NOT NULL,
    "volume" REAL NOT NULL,
    "avgVolume" REAL NOT NULL,
    "marketCap" REAL NOT NULL,
    "sector" TEXT NOT NULL,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "ScanHistory" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "filtersJson" TEXT NOT NULL,
    "resultCount" INTEGER NOT NULL,
    "durationMs" INTEGER NOT NULL,
    "topSymbols" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "Watchlist" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "symbol" TEXT NOT NULL,
    "pinned" BOOLEAN NOT NULL DEFAULT false,
    "notify" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateIndex
CREATE UNIQUE INDEX "Calculation_shareToken_key" ON "Calculation"("shareToken");

-- CreateIndex
CREATE INDEX "Calculation_createdAt_idx" ON "Calculation"("createdAt");

-- CreateIndex
CREATE INDEX "Calculation_shareToken_idx" ON "Calculation"("shareToken");

-- CreateIndex
CREATE INDEX "ScannerResult_score_idx" ON "ScannerResult"("score");

-- CreateIndex
CREATE INDEX "ScannerResult_createdAt_idx" ON "ScannerResult"("createdAt");

-- CreateIndex
CREATE INDEX "ScannerResult_symbol_idx" ON "ScannerResult"("symbol");

-- CreateIndex
CREATE UNIQUE INDEX "ScannerResult_symbol_date_key" ON "ScannerResult"("symbol", "date");

-- CreateIndex
CREATE UNIQUE INDEX "MarketSnapshot_symbol_key" ON "MarketSnapshot"("symbol");

-- CreateIndex
CREATE UNIQUE INDEX "Watchlist_symbol_key" ON "Watchlist"("symbol");

